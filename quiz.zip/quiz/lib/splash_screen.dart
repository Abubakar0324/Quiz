import 'dart:async';
import 'package:flutter/material.dart';
import 'package:quiz/const/colors.dart';
import 'package:quiz/pages/register_page.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Timer(const Duration(seconds: 3) , (){
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) =>const RegisterPage() ,));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColor,
      body: Stack(
        children: <Widget>[
          Positioned(
            top: 100,
              left: 20,
              child: Image.asset('assets/icons/Ellipse11.png')
          ),
          Positioned(
              top: 320,
              right: 1,
              child: Image.asset('assets/icons/Ellipse11.png')
          ),
          Positioned(
              top: 330,
              left: 45,
              child: Image.asset('assets/icons/Ellipse9.png')
          ),
          Positioned(
              top: 240,
              right: 110,
              child: Image.asset('assets/icons/Polygon1.png')
          ),
          Positioned(
              top: 160,
              right: 110,
              child: Image.asset('assets/icons/Ellipse9.png')
          ),
          Positioned(
              top: 470,
              left: 45,
              child: Image.asset('assets/icons/Ellipse10.png')
          ),
          Positioned(
              top: 500,
              right: 45,
              child: Image.asset('assets/icons/Ellipse10.png')
          ),
          const Center(child: Text("Welcome",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold,color: Colors.white),))
        ],
      ),
    );
  }
}
