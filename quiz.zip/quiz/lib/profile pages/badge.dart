import 'package:flutter/material.dart';

class BadgePage extends StatefulWidget {
  const BadgePage({super.key});

  @override
  State<BadgePage> createState() => _BadgePageState();
}

class _BadgePageState extends State<BadgePage> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Center(
          child: Container(
              color: Colors.white,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                        top: 30,
                        left: 8,
                        right: 8,
                        bottom: 8),
                    child: Row(
                      mainAxisAlignment:
                      MainAxisAlignment
                          .spaceAround,
                      children: [
                        GestureDetector(
                            onTap: () {},
                            child: Image.asset(
                                "assets/icons/3.png")),
                        GestureDetector(
                            onTap: () {},
                            child: Image.asset(
                                "assets/icons/2.png")),
                        GestureDetector(
                            onTap: () {},
                            child: Image.asset(
                                "assets/icons/1.png")),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                        top: 16,
                        left: 8,
                        right: 8,
                        bottom: 8),
                    child: Row(
                      mainAxisAlignment:
                      MainAxisAlignment
                          .spaceAround,
                      children: [
                        GestureDetector(
                            onTap: () {},
                            child: Image.asset(
                                "assets/icons/4.png")),
                        GestureDetector(
                            onTap: () {},
                            child: Image.asset(
                                "assets/icons/5.png")),
                        GestureDetector(
                            onTap: () {},
                            child: Image.asset(
                                "assets/icons/6.png")),
                      ],
                    ),
                  ),
                ],
              ))),
    );
  }
}
