import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../screens/profile_page.dart';

class StatPage extends StatefulWidget {
  const StatPage({super.key});

  @override
  State<StatPage> createState() => _StatPageState();
}

class _StatPageState extends State<StatPage> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Center(
          child: Column(
            children: [
              Container(
                margin:const EdgeInsets.all(12),
                height: 450,
                width: double.infinity,
                decoration: BoxDecoration(
                  color:const Color.fromARGB(
                      255, 235, 233, 233),
                  borderRadius:
                  BorderRadius.circular(20),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      child: Image.asset(
                          "assets/icons/Vector8.png"),
                    ),
                    Positioned(
                      child: Image.asset(
                          "assets/icons/Vector7.png"),
                    ),
                    Positioned(
                      right: 10,
                      top: 10,
                      child: Container(
                        height: 35,
                        width: 100,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                          BorderRadius.circular(10),
                        ),
                        child:const Row(
                          mainAxisAlignment:
                          MainAxisAlignment
                              .spaceAround,
                          children: [
                            Text("Monthly"),
                            Icon(Icons
                                .keyboard_arrow_down_rounded)
                          ],
                        ),
                      ),
                    ),
                    const Positioned(
                      top: 100,
                      right: 50,
                      child: Row(
                        children: [
                          Text(
                            "24 quizzes ",
                            style: TextStyle(
                                color:
                                Color(0xFF6A5AE0),
                                fontSize: 20,
                                fontWeight:
                                FontWeight.bold),
                          ),
                          Text(
                            "this month!",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight:
                                FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                    const Positioned(
                      top: 80,
                      right: 50,
                      child: Text(
                        "You Have Played a total",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight:
                            FontWeight.bold),
                      ),
                    ),
                    Positioned(
                      top: 140,
                      right: 80,
                      child: CircularPercentIndicator(
                        radius: 80.0,
                        lineWidth: 10.0,
                        percent: 0.8,
                        center: const Padding(
                          padding:
                          EdgeInsets.only(
                              top: 60),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment
                                    .center,
                                children: [
                                  Text("21",
                                      style: TextStyle(
                                          fontSize: 26,
                                          fontWeight:
                                          FontWeight
                                              .bold,
                                          color: Colors
                                              .black)),
                                  Text("/24",
                                      style: TextStyle(
                                          color: Color
                                              .fromARGB(
                                              255,
                                              118,
                                              87,
                                              175))),
                                ],
                              ),
                              Text("quiz played",
                                  style: TextStyle(
                                      color: Color
                                          .fromARGB(
                                          255,
                                          118,
                                          87,
                                          175)))
                            ],
                          ),
                        ),
                        backgroundColor: Colors.white,
                        progressColor:
                        const Color(0xFF6A5AE0),
                      ),
                    ),
                    Positioned(
                      bottom: 10,
                      child: Row(
                        children: [
                          Container(
                            margin:const EdgeInsets.all(8),
                            height: 100,
                            width: 140,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius:
                              BorderRadius.circular(
                                  10),
                            ),
                            child:const Padding(
                              padding:
                              EdgeInsets.only(
                                  left: 12,
                                  top: 20),
                              child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,
                                children: [
                                  Text(
                                    "3",
                                    style: TextStyle(
                                        fontSize: 32,
                                        fontWeight:
                                        FontWeight
                                            .bold),
                                  ),
                                  Text("Quiz Lose")
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin:const EdgeInsets.all(8),
                            height: 100,
                            width: 140,
                            decoration: BoxDecoration(
                              color:const Color(0xFF6A5AE0),
                              borderRadius:
                              BorderRadius.circular(
                                  10),
                            ),
                            child:const Padding(
                              padding:
                              EdgeInsets.only(
                                  left: 12,
                                  top: 20),
                              child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,
                                children: [
                                  Text(
                                    "21",
                                    style: TextStyle(
                                        color: Colors
                                            .white,
                                        fontSize: 32,
                                        fontWeight:
                                        FontWeight
                                            .bold),
                                  ),
                                  Text(
                                    "Quiz Lose",
                                    style: TextStyle(
                                        color: Colors
                                            .white),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              Container(
                margin:const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color:const Color(0xFF6A5AE0),
                  borderRadius:
                  BorderRadius.circular(20),
                ),
                height: 450,
                child: Column(
                  children: [
                    Padding(
                      padding:
                      const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment
                            .spaceBetween,
                        children: [
                          const Text(
                            "Top performance by\ncataegory",
                            style: TextStyle(
                                fontWeight:
                                FontWeight.bold,
                                fontSize: 20,
                                color: Colors.white),
                          ),
                          Image.asset("assets/icons/bar.png")
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                      const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment
                            .spaceAround,
                        children: [
                          Row(
                            children: [
                              Container(
                                height: 10,
                                width: 10,
                                decoration: BoxDecoration(
                                    color:
                                    const Color.fromARGB(
                                        255,
                                        231,
                                        168,
                                        191),
                                    borderRadius:
                                    BorderRadius
                                        .circular(
                                        10)),
                              ),
                              const Text(
                                "Math",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight:
                                    FontWeight.bold,
                                    color:
                                    Colors.white),
                              )
                            ],
                          ),
                          Row(
                            children: [
                              Container(
                                height: 10,
                                width: 10,
                                decoration: BoxDecoration(
                                    color: const Color
                                        .fromARGB(255,
                                        154, 223, 156),
                                    borderRadius:
                                    BorderRadius
                                        .circular(
                                        10)),
                              ),
                              const Text(
                                "Sports",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight:
                                    FontWeight.bold,
                                    color:
                                    Colors.white),
                              )
                            ],
                          ),
                          Row(
                            children: [
                              Container(
                                height: 10,
                                width: 10,
                                decoration: BoxDecoration(
                                    color: const Color
                                        .fromARGB(255,
                                        162, 191, 214),
                                    borderRadius:
                                    BorderRadius
                                        .circular(
                                        10)),
                              ),
                              const Text(
                                "Music",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight:
                                    FontWeight.bold,
                                    color:
                                    Colors.white),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                    SfCartesianChart(
                      primaryXAxis:const CategoryAxis(
                        majorGridLines:
                        MajorGridLines(width: 0),
                        labelStyle: TextStyle(
                            color: Colors.white),
                      ),
                      plotAreaBorderWidth: 0,
                      primaryYAxis:const NumericAxis(
                        labelFormat: '{value}%',
                        interval: 25,
                        minimum: 0,
                        maximum: 100,
                        axisLine: AxisLine(width: 0),
                        majorGridLines:
                        MajorGridLines(
                          width: 0.5,
                          dashArray: <double>[12, 3],
                        ),
                        labelStyle: TextStyle(
                            color: Colors.white),
                      ),
                      series: <CartesianSeries>[
                        // Render bar chart
                        ColumnSeries<ChartData,
                            String>(
                          dataSource: <ChartData>[
                            ChartData(
                                '3/10\nQuestions\nAnswered',
                                30,
                                Colors.red),
                            ChartData(
                                '8/10\nQuestions\nAnswered',
                                80,
                                Colors.white),
                            ChartData(
                                '6/10\nQuestions\nAnswered',
                                55,
                                Colors.red),
                          ],
                          xValueMapper:
                              (ChartData sales, _) =>
                          sales.x,
                          yValueMapper:
                              (ChartData sales, _) =>
                          sales.y,
                          borderRadius:
                          BorderRadius.circular(
                              6),
                          dataLabelSettings:
                          const DataLabelSettings(
                              isVisible: false),
                          // color: Colors.blue,
                        ),
                      ],
                    )
                  ],
                ),
              )
            ],
          )),
    );
  }
}
