import 'package:flutter/material.dart';
import 'package:quiz/pages/login_page.dart';
import 'package:quiz/screens/home_page.dart';

import '../dashboard_page.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [

            const SizedBox(height: 30,),

            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Register',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 18),),
              ],
            ),

            const SizedBox(height: 120,),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                cursorColor: Colors.grey.shade300,
                decoration: InputDecoration(
                  hintText: 'Enter your mobile number',
                  hintStyle: TextStyle(color: Colors.grey.shade300,fontSize: 14),
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.grey.shade300,
                          width: 1
                      )
                  ),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.grey.shade300,
                          width: 1
                      )
                  ),
                  errorBorder:const OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1
                      )
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20,),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                cursorColor: Colors.grey.shade300,
                decoration: InputDecoration(
                  hintText: 'Password',
                  hintStyle: TextStyle(color: Colors.grey.shade300,fontSize: 14),
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.grey.shade300,
                          width: 1
                      )
                  ),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.grey.shade300,
                          width: 1
                      )
                  ),
                  errorBorder:const OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1
                      )
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20,),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                cursorColor: Colors.grey.shade300,
                decoration: InputDecoration(
                  hintText: 'Confirm Password',
                  hintStyle: TextStyle(color: Colors.grey.shade300,fontSize: 14),
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.grey.shade300,
                          width: 1
                      )
                  ),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.grey.shade300,
                          width: 1
                      )
                  ),
                  errorBorder:const OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1
                      )
                  ),
                ),
              ),
            ),

            const SizedBox(height: 30,),

            GestureDetector(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => const HomePage() ));
              },
              child: Container(
                width: 250,
                height: 50,
                decoration: BoxDecoration(
                    color:const Color(0xffFCAB2F),
                    borderRadius: BorderRadius.circular(4)
                ),
                child:const Center(child: Text('Register',style: TextStyle(color: Colors.white,fontSize: 16),)),
              ),
            ),

           const SizedBox(height: 40,),

           Padding(
             padding: const EdgeInsets.only(left: 20),
             child: Row(
               children: [
                 Text('if you have already account',style: TextStyle(color: Colors.grey.shade300,fontSize: 14),),
                  GestureDetector(
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginPage() ));
                    },
                      child:const Text(' click here',style: TextStyle(fontSize: 14,color: Color(0xffFCAB2F),),)),
               ],
             ),
           )

          ],
        ),
      ),
    );
  }
}
