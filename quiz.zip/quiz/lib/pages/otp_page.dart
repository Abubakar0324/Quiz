import 'package:flutter/material.dart';
import 'package:quiz/dashboard_page.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';
import 'package:quiz/screens/home_page.dart';

class OtpPage extends StatefulWidget {
  const OtpPage({super.key});

  @override
  State<OtpPage> createState() => _OtpPageState();
}

class _OtpPageState extends State<OtpPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [

            const SizedBox(height: 30,),

            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Login',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 18),),
              ],
            ),

            const SizedBox(height: 100,),
            
            const Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 40),
                  child: Text('Enter your 6 digit otp here'),
                ),
              ],
            ),

            const SizedBox(height: 20,),

           const OTPTextField(
              length: 5,
              width: 200,
              textFieldAlignment: MainAxisAlignment.spaceAround,
              fieldStyle: FieldStyle.underline,
              //onCompleted: (pin) {},
            ),

            const SizedBox(height: 50,),

            GestureDetector(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => const HomePage() ));
              },
              child: Container(
                height: 50,
                width: 250,
                decoration: BoxDecoration(
                    color:const Color(0xffFCAB2F),
                    borderRadius: BorderRadius.circular(4)
                ),
                child:const Center(child: Text('Login',style: TextStyle(color: Colors.white,fontSize: 16),)),
              ),
            ),

           const  SizedBox(height: 20,),

            const Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 75),
                  child: Text('login with social media'),
                ),
              ],
            ),
            
            
            Expanded(

                child: Align(
                  alignment: Alignment.bottomCenter,
                    child: Image.asset('assets/icons/clipart-Otp.png'))),
            const SizedBox(height: 20,)

          ],
        ),
      ),
    );
  }
}
