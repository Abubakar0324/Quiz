import 'package:flutter/material.dart';
import 'package:quiz/pages/otp_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: SafeArea(
        child: Column(
         crossAxisAlignment: CrossAxisAlignment.center,
          children: [

            const SizedBox(height: 30,),

            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Login',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 18),),
              ],
            ),

            const SizedBox(height: 60,),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                Image.asset('assets/icons/clipart.png'),
                const SizedBox(width: 30,),
                Padding(
                  padding: const EdgeInsets.only(top: 60),
                  child: Image.asset('assets/Logo.png'),
                ),

              ],
            ),

            const SizedBox(height: 70,),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                cursorColor: Colors.grey.shade300,
                decoration: InputDecoration(
                  hintText: 'Enter your mobile number',
                  hintStyle: TextStyle(color: Colors.grey.shade300),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.grey.shade300,
                      width: 1
                    )
                  ),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.grey.shade300,
                          width: 1
                      )
                  ),
                  errorBorder:const OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.red,
                          width: 1
                      )
                  ),
                ),
              ),
            ),

            const SizedBox(height: 35,),

            GestureDetector(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => const OtpPage() ));
              },
              child: Container(
                height: 50,
                width: 250,
                decoration: BoxDecoration(
                  color:const Color(0xffFCAB2F),
                  borderRadius: BorderRadius.circular(4)
                ),
                child:const Center(child: Text('Login',style: TextStyle(color: Colors.white,fontSize: 16),)),
              ),
            ),
            
            Expanded(
                child:Align(
                  alignment: Alignment.bottomCenter,
                    child: Text('Terms and condition apply',style: TextStyle(color: Colors.grey.shade300,fontSize: 12),))
            ),
            const SizedBox(height: 30,)

          ],
        ),
      ),
    );
  }
}
