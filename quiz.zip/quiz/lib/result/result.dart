import 'package:flutter/material.dart';
import 'package:quiz/const/colors.dart';
import 'package:quiz/result/review_answer.dart';

class Result extends StatefulWidget {
  const Result({super.key});

  @override
  State<Result> createState() => _ResultState();
}

class _ResultState extends State<Result> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColor,
      body: SafeArea(
        child: Stack(
          children: <Widget>[

            Positioned(
              left: 150,
              top: 178,
              child: Container(
                height: 55,
                width: 60,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50),
                  color: Colors.white,
                ),
              ),
            ),

            Column(
              children: [


                const SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          GestureDetector(
                              onTap:(){
                                Navigator.pop(context);
                              },
                              child: Image.asset('assets/icons/backIcon.png')),
                          const SizedBox(height: 40,),

                          const Padding(
                            padding:  EdgeInsets.only(left: 110),
                            child:  Text('Result',style: TextStyle(color: Colors.white,fontSize: 26,fontWeight: FontWeight.w500),),
                          ),

                        ],
                      ),

                      const SizedBox(height: 24,),

                      Row(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                color:const Color(0xff5B4EC3),
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(color: Colors.grey.shade300,width: 0.5)
                            ),
                            child:const  Padding(
                              padding:  EdgeInsets.all(20.0),
                              child: Text('Math Quiz',style: TextStyle(color: Colors.white,fontSize: 16),),
                            ),
                          ),
                        ],
                      )

                    ],
                  ),
                ),

                Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Container(
                        decoration:const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.vertical(
                              bottom: Radius.elliptical(30, 30),
                              top: Radius.elliptical(30, 30)
                          ),
                        ),
                        child: Column(
                          children: [

                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  height: 10,
                                  width: 10,
                                  decoration: BoxDecoration(
                                      color: appColor,
                                      borderRadius: BorderRadius.circular(15)
                                  ),
                                ),
                              ],
                            ),

                        const SizedBox(height: 15,),

                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: Container(
                            height: 150,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(30),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.5),
                                  spreadRadius: 1,
                                  blurRadius: 7,
                                  offset:const Offset(0, 3), // changes position of shadow
                                ),
                              ],
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [

                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [

                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(top: 8),
                                            child: Container(
                                              height: 15,
                                              width: 15,
                                              decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(15),
                                                color:const  Color(0xffA42FC1)
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 5,),
                                          const Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text('100%',style: TextStyle(color: Color(0xffA42FC1),fontWeight: FontWeight.w500,fontSize: 20),),
                                              Text('Completion',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 16),),
                                            ],
                                          )
                                        ],
                                      ),

                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(top: 8),
                                            child: Container(
                                              height: 15,
                                              width: 15,
                                              decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(15),
                                                  color:const  Color(0xff1F8435)
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 5,),
                                          const Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text('5',style: TextStyle(color: Color(0xff1F8435),fontWeight: FontWeight.w500,fontSize: 20),),
                                              Text('Correct',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 16),),
                                            ],
                                          )
                                        ],
                                      ),

                                    ],
                                  ),

                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [

                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(top: 8),
                                            child: Container(
                                              height: 15,
                                              width: 15,
                                              decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(15),
                                                  color:const  Color(0xffA42FC1)
                                              ),
                                            ),
                                          ),
                                         const  SizedBox(width: 5,),
                                          const Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text('5',style: TextStyle(color: Color(0xffA42FC1),fontWeight: FontWeight.w500,fontSize: 20),),
                                              Text('Total Questions',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 16),),
                                            ],
                                          )
                                        ],
                                      ),

                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(top: 8),
                                            child: Container(
                                              height: 15,
                                              width: 15,
                                              decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(15),
                                                  color:const  Color(0xffFA3939)
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 5,),
                                          const Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text('0',style: TextStyle(color: Color(0xffFA3939),fontWeight: FontWeight.w500,fontSize: 20),),
                                              Text('Wrong',style: TextStyle(fontWeight: FontWeight.w500,fontSize: 16),),
                                            ],
                                          )
                                        ],
                                      ),

                                    ],
                                  ),

                                ],
                              ),
                            ),
                          ),
                        ),

                            const Spacer(),

                            const Stack(
                                alignment: Alignment.center,
                                children: [
                                  SizedBox(
                                    child: CircularProgressIndicator.adaptive(
                                      strokeWidth: 10,
                                      strokeAlign: 10,
                                      value: 0.75,
                                      backgroundColor: Color(0xff6066D0),
                                      valueColor: AlwaysStoppedAnimation<Color>(Color(0xffFCAB2F)),
                            
                                    ),
                                  ),
                                  Center(
                                      child: Column(
                                        children: [
                            
                                          Text('12:45',style: TextStyle(color: Color(0xffFF6F41),fontSize: 24,fontWeight: FontWeight.w500),),
                                          Text('Countdown',style: TextStyle(color: Color(0xffFCA82F),fontSize: 14,fontWeight: FontWeight.w500),),
                            
                                        ],
                                      )
                                  ),
                                ]),

                            const Spacer(),

                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 25),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [

                                  Column(
                                    children: [
                                      Container(
                                        height:50,
                                        width: 50,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(30),
                                          color:const  Color(0xff1D7FA9)
                                        ),
                                        child:const Center(
                                          child: Icon(Icons.replay,size: 30,color: Colors.white,),
                                        ),
                                      ),
                                      const SizedBox(height: 5,),
                                      const Text('Play Again'),
                                    ],
                                  ),

                                  Column(
                                    children: [
                                      GestureDetector(
                                        onTap: (){
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => const ReviewAnswer() ));
                                        },
                                        child: Container(
                                          height:50,
                                          width: 50,
                                          decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(30),
                                              color:const  Color(0xffCB9771)
                                          ),
                                          child:const Center(
                                            child: Icon(Icons.remove_red_eye_rounded,size: 30,color: Colors.white,),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 5,),
                                      const Text('Review Answer'),
                                    ],
                                  ),

                                  Column(
                                    children: [
                                      Container(
                                        height:50,
                                        width: 50,
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(30),
                                            color:const  Color(0xff6680DB)
                                        ),
                                        child:const Center(
                                          child: Icon(Icons.share_outlined,size: 30,color: Colors.white,),
                                        ),
                                      ),
                                      const SizedBox(height: 5,),
                                      const Text('Share Score'),
                                    ],
                                  ),

                                ],
                              ),
                            ),

                            const SizedBox(height: 10,),

                          ],
                        ),
                      ),
                    )
                ),

              ],
            ),

          ],
        ),
      ),
    );
  }
}
