import 'package:flutter/material.dart';
import 'package:quiz/quizzes/quiz%20tabs/categories_tab.dart';
import 'package:quiz/quizzes/quiz%20tabs/friends_tab.dart';
import 'package:quiz/quizzes/quiz%20tabs/quiz_tab.dart';
import 'package:quiz/quizzes/quiz%20tabs/top_tab.dart';

import '../const/colors.dart';

class SeeAllQuiz extends StatelessWidget {
  const SeeAllQuiz({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        backgroundColor:const Color(0xFF6A5AE0),
        appBar: AppBar(
          toolbarHeight: 80,
          centerTitle: true,
          backgroundColor:const Color(0xFF6A5AE0),
          title:const Text(
            "Discover",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          leading:const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
        ),
        body: Stack(
          children: [

            Positioned(
              left: 150,
              top: 90,
              child: Container(
                height: 55,
                width: 60,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50),
                  color: Colors.white,
                ),
              ),
            ),

            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                Container(
                  padding:const EdgeInsets.all(10),
                  margin:const EdgeInsets.fromLTRB(20, 5, 0, 5),
                  height: 60,
                  width: 100,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade300),
                    color:const Color(0xFF5B4EC3),
                    borderRadius:const BorderRadius.all(Radius.circular(15)),
                  ),
                  child:const Row(
                    children: [
                      Icon(
                        Icons.search,
                        color: Colors.white,
                      ),
                      Expanded(
                        // Wrap the TextField in an Expanded widget
                        child: Padding(
                          padding: EdgeInsets.only(top: 15),
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: "Search",
                              border: InputBorder.none,
                              hintStyle: TextStyle(color: Colors.white),
                            ),
                            style: TextStyle(color: Colors.white),

                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Expanded(
                  child: Container(
                    margin:const EdgeInsets.all(10),
                    padding:const EdgeInsets.only(left: 10,right: 10,bottom: 10),
                    decoration:const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(25))),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 10,
                              width: 10,
                              decoration: BoxDecoration(
                                  color: appColor,
                                  borderRadius: BorderRadius.circular(15)
                              ),
                            ),
                          ],
                        ),
                         const TabBar(
                          labelPadding: EdgeInsets.symmetric(vertical: 15),
                          dividerColor: Colors.transparent,
                          isScrollable:
                          false, // Ensure all tabs are on a single line
                          unselectedLabelColor:
                          Colors.grey, // Color for inactive tab bar options
                          labelColor:
                          Color(0xFF6A5AE0), // Color for active tab bar option
                          tabs: [
                            Text(
                              "Top",
                              style: TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "Quiz",
                              style: TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "Categories",
                              style: TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              "Friends",
                              style: TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.bold),
                            )
                          ],
                          indicator:
                          DotTabIndicator(color: Color(0xFF6A5AE0), radius: 3),
                          automaticIndicatorColorAdjustment: true,
                        ),
                        const  SizedBox(
                          height: 20,
                        ),
                       const  Expanded(
                          child: TabBarView(
                            children: [
                               TopTab(),
                               QuizTab(),
                               CategoriesTab(),
                               FriendsTab(),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class DotTabIndicator extends Decoration {
  final Color color;
  final double radius;

  const DotTabIndicator({required this.color, this.radius = 3});

  @override
  _DotPainter createBoxPainter([VoidCallback? onChanged]) {
    return _DotPainter(this, onChanged);
  }
}

class _DotPainter extends BoxPainter {
  final DotTabIndicator decoration;

  _DotPainter(this.decoration, VoidCallback? onChanged) : super(onChanged);

  @override
  void paint(Canvas canvas, Offset offset, ImageConfiguration configuration) {
    final center = Offset(offset.dx + configuration.size!.width / 2,
        configuration.size!.height - decoration.radius - 2);
    final paint = Paint()..color = decoration.color;
    canvas.drawCircle(center, decoration.radius, paint);
  }
}
