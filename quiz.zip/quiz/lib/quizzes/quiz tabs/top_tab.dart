import 'package:flutter/material.dart';

import '../../const/colors.dart';
import '../quiz_page.dart';

class TopTab extends StatefulWidget {
  const TopTab({super.key});

  @override
  State<TopTab> createState() => _TopTabState();
}

class _TopTabState extends State<TopTab> {
  @override
  Widget build(BuildContext context) {
    return Container(
        color: Colors.white,
        child: Column(
            children: [
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment:
              MainAxisAlignment.spaceBetween,
              children: [
                Text("Quiz",
                    style:TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700)),
                Text(
                  "See All",
                  style: TextStyle(
                      fontSize: 15,
                      color: Color(0xFF6A5AE0),
                      fontWeight: FontWeight.w500),
                )
              ],
            ),
          ),
          const SizedBox(
            height: 10,
          ),

              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                  
                      Container(
                        decoration: BoxDecoration(
                            borderRadius:const BorderRadius.all(
                              Radius.circular(20),
                            ),
                            color: Colors.white,
                            border: Border.all(
                                color: Colors.grey.shade300)),
                        child: ListTile(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => const QuizPage() ));
                          },
                          leading: Image.asset("assets/icons/Frame1.png"),
                          title:const Text("Statistics Math Quiz",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700)),
                          subtitle:const Padding(
                            padding:  EdgeInsets.only(top: 5),
                            child: Text(
                              "Math-12 Quizzes",
                              style: TextStyle(
                                  fontSize: 12,
                                  color:  Color.fromARGB(
                                      255, 117, 117, 117),
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                          trailing: Icon(
                            Icons.arrow_forward_ios,
                            color:appColor,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      Container(
                        decoration: BoxDecoration(
                            borderRadius:const BorderRadius.all(
                              Radius.circular(20),
                            ),
                            color: Colors.white,
                            border: Border.all(
                                color: Colors.grey.shade300)),
                        child: ListTile(
                          leading: Image.asset("assets/icons/Frame2.png"),
                          title:const Text("Matrices Quiz",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700)),
                          subtitle:const Padding(
                            padding:  EdgeInsets.only(top: 5),
                            child: Text(
                              "Math-6 Quizzes",
                              style: TextStyle(
                                  fontSize: 12,
                                  color:  Color.fromARGB(
                                      255, 117, 117, 117),
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                          trailing: Icon(
                            Icons.arrow_forward_ios,
                            color: appColor,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      Container(
                        decoration: BoxDecoration(
                            borderRadius:const BorderRadius.all(
                              Radius.circular(20),
                            ),
                            color: Colors.white,
                            border: Border.all(
                                color: Colors.grey.shade300)),
                        child: ListTile(
                          leading: Image.asset("assets/icons/Frame2.png"),
                          title:const Text("English Quiz",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700)),
                          subtitle:const Padding(
                            padding:  EdgeInsets.only(top: 5),
                            child: Text(
                              "Language-6 Quizzes",
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Color.fromARGB(
                                      255, 117, 117, 117),
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                          trailing: Icon(
                            Icons.arrow_forward_ios,
                            color: appColor,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      Container(
                        decoration: BoxDecoration(
                            borderRadius:const BorderRadius.all(
                              Radius.circular(20),
                            ),
                            color: Colors.white,
                            border: Border.all(
                                color: Colors.grey.shade300)),
                        child: ListTile(
                          leading: Image.asset("assets/icons/Frame2.png"),
                          title:const Text("Science Quiz",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700)),
                          subtitle:const Padding(
                            padding: EdgeInsets.only(top: 5),
                            child: Text(
                              "Language-4 Quizzes",
                              style: TextStyle(
                                  fontSize: 12,
                                  color:  Color.fromARGB(
                                      255, 117, 117, 117),
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                          trailing: Icon(
                            Icons.arrow_forward_ios,
                            color: appColor,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      Container(
                        decoration: BoxDecoration(
                            borderRadius:const BorderRadius.all(
                              Radius.circular(20),
                            ),
                            color: Colors.white,
                            border: Border.all(
                                color: Colors.grey.shade300)),
                        child: ListTile(
                          leading: Image.asset("assets/icons/Frame2.png"),
                          title:const Text("Biology Quiz",
                              style:TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700)),
                          subtitle:const Padding(
                            padding: EdgeInsets.only(top: 5),
                            child: Text(
                              "Advance-8 Quizzes",
                              style: TextStyle(
                                  fontSize: 12,
                                  color:  Color.fromARGB(
                                      255, 117, 117, 117),
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                          trailing: Icon(
                            Icons.arrow_forward_ios,
                            color: appColor,
                          ),
                        ),
                      ),
                  
                    ],
                  ),
                ),
              )

        ]));
  }
}
