class QuizData {
  static const List<Map<String, dynamic>> quizData = [
    {
      'title': 'Statistics Math Quiz',
      'image': 'assets/icons/LqFrame1.png',
      'subtitle': 'Math - 12 Quizzes',
    },
    {
      'title': 'Integer Quiz',
      'image': 'assets/icons/LqFrame2.png',
      'subtitle': 'Math - 12 Quizzes',
    }, {
      'title': 'Matrices quiz',
      'image': 'assets/icons/Frame1.png',
      'subtitle': 'Math - 6 Quizzes',
    }, {
      'title': 'English Quiz',
      'image': 'assets/icons/Frame2.png',
      'subtitle': 'Language - 6 Quizzes',
    }, {
      'title': 'Science Quiz',
      'image': 'assets/icons/Frame2.png',
      'subtitle': 'Advance - 6 Quizzes',
    }, {
      'title': 'Biology Quiz',
      'image': 'assets/icons/Frame1.png',
      'subtitle': 'Advance - 6 Quizzes',
    }, {
      'title': 'Computer Science Quiz',
      'image': 'assets/icons/Frame2.png',
      'subtitle': 'Computer - 6 Quizzes',
    }, {
      'title': 'Android Quiz',
      'image': 'assets/icons/Frame1.png',
      'subtitle': 'Advance - 6 Quizzes',
    }, {
      'title': 'Data Science Quiz',
      'image': 'assets/icons/Frame2.png',
      'subtitle': 'Advance - 6 Quizzes',
    },
  ];
}
