import 'package:flutter/material.dart';
import 'package:quiz/const/colors.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:quiz/quizzes/quiz_page_2.dart';


class QuizPage extends StatefulWidget {
  final data1;
  const QuizPage({super.key, this.data1});

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {

  late bool ans1= false;
  late bool ans2= false;
  late bool ans3= false;
  late bool ans4= false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColor,
      body: SafeArea(
        child: Stack(
          children: <Widget>[

            Positioned(
              left: 150,
              top: 178,
              child: Container(
                height: 55,
                width: 60,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50),
                  color: Colors.white,
                ),
              ),
            ),

            Column(
              children: [

                const SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [

                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          GestureDetector(
                              onTap:(){
                                Navigator.pop(context);
                              },
                              child: Image.asset('assets/icons/backIcon.png')),
                          const SizedBox(height: 40,),
                          Container(
                            decoration: BoxDecoration(
                                color:const Color(0xff5B4EC3),
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(color: Colors.grey.shade300,width: 0.5)
                            ),
                            child:const  Padding(
                              padding:  EdgeInsets.all(20.0),
                              child: Text('Math Quiz',style: TextStyle(color: Colors.white,fontSize: 16),),
                            ),
                          )
                        ],
                      ),

                      const Text('Quiz',style: TextStyle(color: Colors.white,fontSize: 26,fontWeight: FontWeight.w500),),

                      const Stack(
                          alignment: Alignment.center,
                          children: [
                            SizedBox(
                              height:120,
                              width: 120,
                              child: CircularProgressIndicator.adaptive(
                                value: 0.75,
                                backgroundColor: Color(0xff6066D0),
                                valueColor: AlwaysStoppedAnimation<Color>(Color(0xffFCAB2F)),

                              ),
                            ),
                            Center(
                                child: Column(
                                  children: [

                                    Text('12:45',style: TextStyle(color: Color(0xffFFE141),fontSize: 24,fontWeight: FontWeight.w500),),
                                    Text('Countdown',style: TextStyle(color: Color(0xffDE9854),fontSize: 14,fontWeight: FontWeight.w500),),

                                  ],
                                )
                            ),
                          ]),

                    ],
                  ),
                ),

                Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Container(
                        decoration:const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.vertical(
                              bottom: Radius.elliptical(30, 30),
                              top: Radius.elliptical(30, 30)
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  height: 10,
                                  width: 10,
                                  decoration: BoxDecoration(
                                      color: appColor,
                                      borderRadius: BorderRadius.circular(15)
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height:5),

                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 25),
                              child: Container(
                                decoration: BoxDecoration(
                                    color:const Color(0xffFBFBFB),
                                    borderRadius: BorderRadius.circular(30),
                                    border: Border.all(color: Colors.grey.shade300)
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 15),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(30),
                                    ),
                                    child: LinearPercentIndicator(
                                      barRadius:const Radius.circular(15),
                                      animation: true,
                                      lineHeight: 20.0,
                                      animationDuration: 2500,
                                      percent: 0.5,
                                      trailing:const Text('1/5'),
                                      backgroundColor: Colors.white,
                                      progressColor:const Color(0xffFCAB2F),
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 20,),

                            Padding(
                              padding: const EdgeInsets.only(left: 15),
                              child: Text("Question - 1",style: TextStyle(color: appColor,fontWeight: FontWeight.w500,fontSize: 15),),
                            ),

                            const SizedBox(height: 15,),

                             Padding(
                              padding:const EdgeInsets.only(left: 15),
                              child: Text(widget.data1['Quiz']['questions'][0]['questionText'].toString(),style:const TextStyle(fontWeight: FontWeight.w500,fontSize: 18),),
                            ),

                            const SizedBox(height: 20,),

                            GestureDetector(
                              onTap: (){
                                setState(() {
                                  ans1=true;
                                  ans2=false;
                                  ans3=false;
                                  ans4=false;
                                });
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 15),
                                child: Container(
                                  height: 40,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 1,
                                        blurRadius: 7,
                                        offset:const Offset(0, 3), // changes position of shadow
                                      ),
                                    ],
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 6),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                         Text(widget.data1['Quiz']['questions'][0]['options'][0]['answerText'].toString(),style: TextStyle(fontWeight: FontWeight.w400,fontSize: 18),),
                                        ans1?Container(
                                          height: 30,
                                          width: 30,
                                          decoration: BoxDecoration(
                                            color:const Color(0xffFCA82F),
                                            borderRadius: BorderRadius.circular(30),
                                          ),
                                          child:const Center(child: Icon(Icons.check,color: Colors.white,),),
                                        ):Container()
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 20,),

                            GestureDetector(
                              onTap: (){
                                setState(() {
                                  ans1=false;
                                  ans3=false;
                                  ans4=false;
                                  ans2=true;
                                });
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 15),
                                child: Container(
                                  height: 40,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 1,
                                        blurRadius: 7,
                                        offset:const Offset(0, 3), // changes position of shadow
                                      ),
                                    ],
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 6),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                         Text(widget.data1['Quiz']['questions'][0]['options'][1]['answerText'].toString(),style: TextStyle(fontWeight: FontWeight.w400,fontSize: 18),),
                                        ans2?Container(
                                          height: 30,
                                          width: 30,
                                          decoration: BoxDecoration(
                                            color:const Color(0xffFCA82F),
                                            borderRadius: BorderRadius.circular(30),
                                          ),
                                          child:const Center(child: Icon(Icons.check,color: Colors.white,),),
                                        ):Container()
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 10,),

                            GestureDetector(
                              onTap: (){
                                setState(() {
                                  ans2=false;
                                  ans1=false;
                                  ans4=false;
                                  ans3=true;
                                });
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 15),
                                child: Container(
                                  height: 40,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 1,
                                        blurRadius: 7,
                                        offset:const Offset(0, 3), // changes position of shadow
                                      ),
                                    ],
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 6),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                         Text(widget.data1['Quiz']['questions'][0]['options'][2]['answerText'].toString(),style: TextStyle(fontWeight: FontWeight.w400,fontSize: 18),),
                                        ans3?Container(
                                          height: 30,
                                          width: 30,
                                          decoration: BoxDecoration(
                                            color:const Color(0xffFCA82F),
                                            borderRadius: BorderRadius.circular(30),
                                          ),
                                          child:const Center(child: Icon(Icons.check,color: Colors.white,),),
                                        ):Container()
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 10,),

                            GestureDetector(
                              onTap: (){
                                setState(() {
                                  ans2=false;
                                  ans3=false;
                                  ans1=false;
                                  ans4=true;
                                });
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 15),
                                child: Container(
                                  height: 40,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 1,
                                        blurRadius: 7,
                                        offset:const Offset(0, 3), // changes position of shadow
                                      ),
                                    ],
                                  ),
                                  child: Padding(
                                    padding:const  EdgeInsets.symmetric(horizontal: 20,vertical: 6),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(widget.data1['Quiz']['questions'][0]['options'][3]['answerText'].toString(),style: TextStyle(fontWeight: FontWeight.w400,fontSize: 18),),
                                        ans4?Container(
                                          height: 30,
                                          width: 30,
                                          decoration: BoxDecoration(
                                            color:const Color(0xffFCA82F),
                                            borderRadius: BorderRadius.circular(30),
                                          ),
                                          child:const Center(child: Icon(Icons.check,color: Colors.white,),),
                                        ):Container()
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            Expanded(
                                child:Align(
                                  alignment: Alignment.bottomCenter,
                                  child: GestureDetector(
                                    onTap: (){
                                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) =>  QuizPage2(data2: widget.data1,) ));
                                    },
                                    child: Container(
                                      decoration: BoxDecoration(
                                          color: appColor,
                                          borderRadius: BorderRadius.circular(4)
                                      ),
                                      child:const Padding(
                                        padding: EdgeInsets.symmetric(horizontal: 40,vertical: 15),
                                        child: Text('NEXT QUESTION',style: TextStyle(color:Colors.white),),
                                      ),
                                    ),
                                  ),
                                )
                            ),

                            const SizedBox(height: 20,),

                          ],
                        ),
                      ),
                    )
                ),

              ],
            ),

          ],
        ),
      ),
    );
  }
}
