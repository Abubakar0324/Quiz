import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:quiz/const/colors.dart';
import 'package:quiz/screens/add_quiz.dart';
import 'package:quiz/screens/home_page.dart';
import 'package:quiz/screens/leaderboard_page.dart';
import 'package:quiz/screens/profile_page.dart';
import 'package:quiz/screens/search.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {

  int index = 0;

  final iconList = <IconData>[
    Icons.home_outlined,
    Icons.search_rounded,
    Icons.leaderboard_outlined,
    Icons.perm_identity,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation:
      FloatingActionButtonLocation.miniCenterDocked,
      floatingActionButton: FloatingActionButton(
        shape: CircleBorder(side: BorderSide(color: appColor)),
        backgroundColor: appColor,
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (builder) => const addQuiz()));
        },
        child:const Icon(
          Icons.add,
          size: 35,
          color: Colors.white,
        ),
      ),
      bottomNavigationBar: AnimatedBottomNavigationBar(
        icons: iconList,
        activeColor: appColor,
        gapLocation: GapLocation.center,
        leftCornerRadius: 30,
        rightCornerRadius: 30,
        iconSize: 30,
        onTap: (selectedIndex) {
          setState(() {
            index = selectedIndex;
          });
        },
        activeIndex: index,
      ),
      body:getSelectedWidget(index:index),
    );
  }

  Widget getSelectedWidget({required int index}){
    Widget widget;
    switch(index){
      case 0:
        widget = const HomePage();
        break;
      case 1:
        widget = const SearchPage();
        break;
      case 2:
        widget = const LeaderBoardPage();
        break;
      default:
        widget = const ProfilePage();
        break;
    }
return widget;

  }

}


// import 'package:curved_labeled_navigation_bar/curved_navigation_bar.dart';
// import 'package:curved_labeled_navigation_bar/curved_navigation_bar_item.dart';
// import 'package:flutter/material.dart';
// import 'package:quiz/const/colors.dart';
// import 'package:quiz/screens/add_quiz.dart';
// import 'package:quiz/screens/home_page.dart';
// import 'package:quiz/screens/leaderboard_page.dart';
// import 'package:quiz/screens/profile_page.dart';
// import 'package:quiz/screens/search.dart';
//
// class DashboardPage extends StatefulWidget {
//   const DashboardPage({super.key});
//
//   @override
//   State<DashboardPage> createState() => _DashboardPageState();
// }
//
// class _DashboardPageState extends State<DashboardPage> {
//
//   int index = 0;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       bottomNavigationBar: CurvedNavigationBar(
//         backgroundColor: Colors.transparent,
//         buttonBackgroundColor: appColor,
//         items:const [
//           CurvedNavigationBarItem(
//             child: Icon(Icons.home_outlined,size: 30,),
//           ),
//           CurvedNavigationBarItem(
//             child: Icon(Icons.search,size: 30,),
//           ),
//           CurvedNavigationBarItem(
//             child: Icon(Icons.add,size: 30,),
//           ),
//           CurvedNavigationBarItem(
//             child: Icon(Icons.leaderboard_outlined,size: 30,),
//           ),
//           CurvedNavigationBarItem(
//             child: Icon(Icons.perm_identity,size: 30,),
//           ),
//         ],
//         index: index,
//         onTap: (selectedIndex) {
//           setState(() {
//             index = selectedIndex;
//           });
//         },
//       ),
//       body:getSelectedWidget(index:index),
//     );
//   }
//
//   Widget getSelectedWidget({required int index}){
//     Widget widget;
//     switch(index){
//       case 0:
//         widget = const HomePage();
//         break;
//       case 1:
//         widget = const SearchPage();
//         break;
//       case 2:
//         widget = const addQuiz();
//         break;
//       case 3:
//         widget = const LeaderboardPage();
//         break;
//       default:
//         widget = const ProfilePage();
//         break;
//     }
//     return widget;
//
//   }
//
// }
