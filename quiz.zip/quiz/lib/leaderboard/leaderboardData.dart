class Data {
  static const List<Map<String, dynamic>> leaderData = [
    {
      'name': 'Davis Curtis',
      'image': 'assets/icons/Davis.png',
      'point': '2,569',
      'medal': 'assets/icons/Medal1.png',
    },
    {
      'name': 'Alena Donin',
      'image': 'assets/icons/Alena.png',
      'point': '1,469',
      'medal': 'assets/icons/Medal2.png',
    },
    {
      'name': 'Craig Gouse',
      'image': 'assets/icons/Craig.png',
      'point': '1,053',
      'medal': 'assets/icons/Medal3.png',
    },
    {
      'name': 'Madelyn Dias',
      'image': 'assets/icons/Dias.png',
      'point': '590',
      'medal': '',
    },
    {
      'name': 'Zain Vaccaro',
      'image': 'assets/icons/Zain.png',
      'point': '488',
      'medal': '',
    },
    {
      'name': 'Skyler Geidt',
      'image': 'assets/icons/Dias.png',
      'point': '448',
      'medal': '',
    },
  ];
}
