import 'package:flutter/material.dart';

class LeaderboardAllTime extends StatefulWidget {
  const LeaderboardAllTime({super.key});

  @override
  State<LeaderboardAllTime> createState() => _LeaderboardAllTimeState();
}

class _LeaderboardAllTimeState extends State<LeaderboardAllTime> {
  @override
  Widget build(BuildContext context) {
    return const Center(
        child: Text('Tab 2 Content')
    );
  }
}
