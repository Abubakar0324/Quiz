import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';

import 'leaderboardData.dart';

class LeaderBoardWeekly extends StatefulWidget {
  const LeaderBoardWeekly({super.key});

  @override
  State<LeaderBoardWeekly> createState() => _LeaderBoardWeeklyState();
}

class _LeaderBoardWeeklyState extends State<LeaderBoardWeekly> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Stack(children: [
        Container(
          margin: const EdgeInsets.all(20),
          width: double.infinity,
          decoration: BoxDecoration(
              color: const Color(0xFFFFB380),
              borderRadius: BorderRadius.circular(20)),
          child: Row(
            children: [
              Container(
                margin: const EdgeInsets.all(12),
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: const Color(0xFFFF9B57),
                ),
                child: const Center(
                  child: Text(
                    "#4",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const Text(
                "Your are doing better than\n60% of other players!",
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14),
              ),
            ],
          ),
        ),
        Stack(
          children: [
            Positioned(
                top: 100,
                child: Image.asset("assets/icons/biggestoval.png")),
            Positioned(
                top: 180,
                child: Image.asset("assets/icons/5thbigoval.png")),
            Positioned(
                top: 250,
                left: 60,
                child: Image.asset("assets/icons/medoval.png")),
            Positioned(
              top:105 ,
              right: 0,
              child: Container(
                width: 100,
                decoration: BoxDecoration(
                    color: const Color(0xFF5144B6),
                    borderRadius: BorderRadius.circular(12)),
                child: const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Icon(
                        FontAwesomeIcons.clock,
                        size: 15,
                        color: Colors.grey,
                      ),
                      Text(
                        " 06d 23h 00m",
                        style: TextStyle(
                            color: Colors.white, fontSize: 10),
                      )
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 170, left: 30),
              child: Column(
                children: [
                  Image.asset(
                    "assets/icons/Alena.png",
                  ),
                  const Text(
                    "Alena Donin",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  Container(
                      height: 25,
                      width: 70,
                      decoration: BoxDecoration(
                          color: const Color(0xFF9087E5),
                          borderRadius: BorderRadius.circular(6)),
                      child: const Center(
                        child: Text(
                          "1,469 QP",
                          style: TextStyle(
                              color: Colors.white, fontSize: 10),
                        ),
                      )),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    height: 150,
                    width: 100,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xFF938AE6),
                          Color(0xfffc3bef1),
                        ],
                        stops: [0.1, 0.4],
                      ),
                    ),
                    child:const  Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "2",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 80,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 120, left: 130),
              child: Column(
                children: [
                  const Icon(
                    FontAwesomeIcons.crown,
                    color: Colors.amber,
                  ),
                  Image.asset(
                    "assets/icons/Davis.png",
                  ),
                  const Text(
                    "Davis Curtis",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  Container(
                      height: 25,
                      width: 70,
                      decoration: BoxDecoration(
                          color: const Color(0xFF9087E5),
                          borderRadius: BorderRadius.circular(6)),
                      child: const Center(
                        child: Text(
                          "2,569 QP",
                          style: TextStyle(
                              color: Colors.white, fontSize: 10),
                        ),
                      )),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    height: 206,
                    width: 100,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xFF938AE6),
                          Color(0xFFFC3BEF1),
                        ],
                        stops: [0.0, 0.5],
                      ),
                    ),
                    child:const Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "1",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 90,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 180, left: 230),
              child: Column(
                children: [
                  Image.asset(
                    "assets/icons/Craig.png",
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Text(
                    "Craig Gouse",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  Container(
                      height: 25,
                      width: 70,
                      decoration: BoxDecoration(
                          color: const Color(0xFF9087E5),
                          borderRadius: BorderRadius.circular(6)),
                      child: const Center(
                        child: Text(
                          "1,053 QP",
                          style: TextStyle(
                              color: Colors.white, fontSize: 10),
                        ),
                      )),
                  const SizedBox(
                    height: 5,
                  ),
                  Container(
                    height: 146,
                    width: 100,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xFF938AE6),
                          Color(0xFFFC3BEF1),
                        ],
                        stops: [0.0, 0.5],
                      ),
                    ),
                    child:const Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "3",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 70,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
        SlidingUpPanel(
          color:const Color.fromARGB(255, 241, 240, 240),
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(12),
              topRight: Radius.circular(12)),
          margin: const EdgeInsets.all(12),
          minHeight: MediaQuery.of(context).size.height * 0.1,
          maxHeight: MediaQuery.of(context).size.height * 0.80,
          panel: ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            itemCount: Data.leaderData.length,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              final person = Data.leaderData[index];
              return Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.white,
                ),
                margin: const EdgeInsets.only(
                    top: 12, left: 12, right: 12),
                child: ListTile(
                  leading: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '${index + 1}',
                        style: const TextStyle(fontSize: 16),
                      ),
                      const SizedBox(width: 10),
                      Image.asset(
                        person['image'],
                        width: 54,
                        height: 54,
                      ),
                    ],
                  ),
                  title: Text(person['name']),
                  subtitle: Text(person['point']),
                  trailing:
                  (index < 3 && person['medal'].isNotEmpty)
                      ? Image.asset(
                    person['medal'],
                    width: 54,
                    height: 54,
                  )
                      : null,
                  onTap: () {},
                ),
              );
            },
          ),
        )
      ]),
    );
  }
}
