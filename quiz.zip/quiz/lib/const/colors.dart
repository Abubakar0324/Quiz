import 'dart:ui';

final appColor = Color(0xff6A5AE0);