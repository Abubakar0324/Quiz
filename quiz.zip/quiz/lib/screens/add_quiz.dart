import 'package:flutter/material.dart';

import '../const/colors.dart';

class addQuiz extends StatefulWidget {
  const addQuiz({Key? key}) : super(key: key);

  @override
  State<addQuiz> createState() => _addQuizState();
}

class _addQuizState extends State<addQuiz> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColor,
      body:const Center(
        child: Text('Add Quiz',style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),),
      ),
    );
  }
}
