import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../const/colors.dart';
import '../quizzes/quiz_list_data.dart';
import '../quizzes/quiz_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  @override
  void initState() {
    getData();
    super.initState();
  }

  var data;

  Future<void> getData() async {

    final String response=await rootBundle.loadString("assets/files/quiz.json");
    setState(() {
       data =  jsonDecode(response);
    });

  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColor,
      body:SafeArea(
        child: Column(
          children: [

            const SizedBox(height: 10,),

            // Padding(
            //   padding: const EdgeInsets.all(20),
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //     children: [
            //
            //       const Column(
            //         crossAxisAlignment: CrossAxisAlignment.start,
            //         children: [
            //
            //           Row(
            //             children: [
            //               Icon(Icons.sunny,color: Colors.yellow,size: 20,),
            //               SizedBox(width: 5,),
            //               Text('GOOD MORNING',style: TextStyle(color: Colors.yellowAccent,fontSize: 13),),
            //             ],
            //           ),
            //
            //           Text('Madelyn Dias',style: TextStyle(color: Colors.white,fontWeight: FontWeight.w500,fontSize: 25),)
            //         ],
            //       ),
            //
            //       Image.asset('assets/icons/Avatar.png')
            //
            //     ],
            //   ),
            // ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: Container(
                decoration: BoxDecoration(
                    color:const Color(0xffFFCCD5),
                  borderRadius:BorderRadius.circular(15),
                ),
                child:Stack(
                  children: [

                    Positioned(
                      left: 7,
                        child: Image.asset('assets/icons/Vector7.png')),

                    Positioned(
                        left: 7,
                        child: Image.asset('assets/icons/Vector8.png')),

                     const Padding(
                      padding: EdgeInsets.all(14.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [

                          // const SizedBox(width: 5,),

                           Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              Text('Recent Quiz',style: TextStyle(color: Color(0xffB36673),fontSize: 17),),

                              SizedBox(height: 5,),

                              Row(
                                children: [
                                  Icon(Icons.headphones,color: Color(0xff660012),),
                                  SizedBox(width: 5,),
                                  Text('A Basic Music Quiz',style: TextStyle(color: Color(0xff660012),fontSize: 17,fontWeight: FontWeight.bold),),
                                ],
                              )

                            ],
                          ),

                          Stack(alignment: Alignment.center, children: [
                            CircularProgressIndicator.adaptive(
                              value: 0.65,
                              backgroundColor: Color(0xffFFB2C0),
                              valueColor: AlwaysStoppedAnimation<Color>(Color(0xffFF8FA2)),

                            ),
                            Center(
                                child: Text(
                                  '65%',
                                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
                                )),
                          ]),

                        ],
                      ),
                    ),

                  ],
                )
              ),
            ),

            // Text(data['Quiz']['questions'].toString()),

            // Padding(
            //   padding: const EdgeInsets.all(15),
            //   child: Container(
            //     decoration: BoxDecoration(
            //       color:const Color(0xffACA5EB),
            //       borderRadius:BorderRadius.circular(15),
            //     ),
            //     height: 230,
            //     child: Stack(
            //       children:<Widget> [
            //
            //         Positioned(
            //           height: 100,
            //             top: 170,
            //             right: 270,
            //             child: Image.asset('assets/icons/Ellipse11.png',)),
            //
            //         Positioned(
            //             top: 145,
            //             right: 245,
            //             child: Image.asset('assets/icons/OvalCopy.png',)),
            //
            //         Positioned(
            //             height: 100,
            //             bottom: 170,
            //             left: 270,
            //             child: Image.asset('assets/icons/Ellipse11.png',)),
            //
            //         Positioned(
            //             bottom: 145,
            //             left: 245,
            //             child: Image.asset('assets/icons/OvalCopy1.png',)),
            //
            //         Padding(
            //           padding: const EdgeInsets.all(15),
            //           child: Row(
            //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //             children: [
            //
            //               Column(
            //                 mainAxisAlignment: MainAxisAlignment.start,
            //                 children: [
            //                   Image.asset('assets/icons/men.png'),
            //                 ],
            //               ),
            //
            //               Column(
            //                 children: [
            //                   const SizedBox(height: 15,),
            //                   const Text("FEATURED",style: TextStyle(color: Colors.white,fontWeight: FontWeight.w400,fontSize: 15),),
            //                   const SizedBox(height: 20,),
            //                   const Text("Take part in Quiz and\nsee your IQ level",textAlign: TextAlign.center,style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18),),
            //
            //                   const SizedBox(height: 25,),
            //
            //                   GestureDetector(
            //                     onTap: (){
            //                       Navigator.push(context, MaterialPageRoute(builder: (context) => const LeaderBoardPage() ));
            //                     },
            //                     child: Container(
            //                       decoration: BoxDecoration(
            //                           color: Colors.white,
            //                           borderRadius: BorderRadius.circular(18)
            //                       ),
            //                       child: Padding(
            //                         padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 10),
            //                         child: Row(
            //                           children: [
            //
            //                             Image.asset('assets/icons/LbButton.png'),
            //                             const SizedBox(width: 10,),
            //                             Text('Leaderboard',style: TextStyle(color:appColor,fontWeight: FontWeight.bold),)
            //
            //                           ],
            //                         ),
            //                       ),
            //                     ),
            //                   )
            //
            //                 ],
            //               ),
            //
            //               Column(
            //                 mainAxisAlignment: MainAxisAlignment.end,
            //                 children: [
            //                   Padding(
            //                     padding: const EdgeInsets.only(bottom: 35),
            //                     child: Image.asset('assets/icons/women.png'),
            //                   ),
            //                 ],
            //               ),
            //
            //             ],
            //           ),
            //         ),
            //
            //       ],
            //     ),
            //   ),
            // ),

            const SizedBox(height: 10,),

            Expanded(
                child:Container(
                  decoration:const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.vertical(
                          top: Radius.elliptical(30, 30)
                      )
                  ),
                  child: Column(
                    children: [

                      const SizedBox(height: 10,),

                      const Padding(
                        padding:  EdgeInsets.symmetric(horizontal: 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                             Text('Quizzes',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
                            // GestureDetector(
                            //   onTap: (){
                            //     Navigator.push(context, MaterialPageRoute(builder: (context) => const SeeAllQuiz() ));
                            //   },
                            //     child: Text('See all',style: TextStyle(color:appColor,fontWeight: FontWeight.w500,fontSize: 14),)),
                          ],
                        ),
                      ),

                      const SizedBox(height: 10,),

                      Expanded(
                        child: ListView.builder(
                            itemCount: data.length,
                            itemBuilder: (context,index){
                              // final data = QuizData.quizData[index];
                              return Padding(
                                padding: const EdgeInsets.only(left: 15,right: 15,bottom: 15),
                                child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(15),
                                      border: Border.all(color: Colors.grey.shade300)
                                  ),
                                  child: ListTile(
                                    onTap: (){
                                      Navigator.push(context, MaterialPageRoute(builder: (context) =>  QuizPage(data1: data,) ));
                                    },
                                    leading: Image.asset("assets/icons/LqFrame2.png"),
                                    title: Text(data['Quiz']['name'].toString(),style:const TextStyle(fontWeight: FontWeight.bold),),
                                    subtitle:const Text("Math Questions"),
                                    trailing: Icon(Icons.arrow_forward_ios,color: appColor,),
                                  ),
                                ),
                              );
                            }
                        ),
                      )

                    ],
                  ),
                )
            ),

          ],
        ),
      ),
    );
  }
}
