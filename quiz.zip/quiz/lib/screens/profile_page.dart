import 'package:flutter/material.dart';
import 'package:quiz/profile%20pages/badge.dart';
import 'package:quiz/profile%20pages/detail.dart';
import 'package:quiz/profile%20pages/stat_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class ChartData {
  final String x;
  final double y;
  final Color color;
  ChartData(this.x, this.y, this.color);
}

class _ProfilePageState extends State<ProfilePage> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:const Color(0xFF6A5AE0),
      body: DefaultTabController(
        length: 3,
        child:  Stack(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10, right: 10, top: 40),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      onPressed: () {},
                      icon:const Icon(
                        Icons.arrow_back,
                        color: Colors.white,
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon:const Icon(
                        Icons.settings,
                        color: Colors.white,
                      ),
                    )
                  ],
                ),
              ),
              Positioned(
                left: 0,
                top: 0,
                child: Image.asset("assets/icons/Group7.png"),
              ),
              Positioned(
                right: 0,
                child: Image.asset("assets/icons/Group8.png"),
              ),
              Positioned(
                top: 49,
                left: 100,
                child: Image.asset("assets/icons/smallOval.png"),
              ),
              Positioned(
                right: 107,
                top: 70,
                child: Image.asset("assets/icons/bigOval.png"),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 120),
                child: Container(
                  margin:const EdgeInsets.symmetric(horizontal: 10),
                  decoration:const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(24),
                        topRight: Radius.circular(24),
                        bottomLeft: Radius.circular(0),
                        bottomRight: Radius.circular(0)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(top: 50),
                    child: Column(
                      children: [
                        const Text(
                          "Madelyn Dias",
                          style: TextStyle(
                              fontSize: 26, fontWeight: FontWeight.bold),
                        ),
                        Container(
                          margin:const EdgeInsets.all(15),
                          height: 110,
                          decoration: BoxDecoration(
                            color:const Color(0xFF6A5AE0),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Padding(
                                padding:
                                const EdgeInsets.only(top: 20, left: 16),
                                child: Column(
                                  children: [
                                    Image.asset("assets/icons/star.png"),
                                    const Text(
                                      "POINTS",
                                      style: TextStyle(
                                          fontSize: 14, color: Colors.grey),
                                    ),
                                    const Text(
                                      "590",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.only(
                                    top: 14.0, bottom: 14),
                                child: VerticalDivider(
                                  width: 12,
                                  thickness: 1,
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 20),
                                child: Column(
                                  children: [
                                    Image.asset("assets/icons/NoWifi.png"),
                                    const Text(
                                      "WORLD RANK",
                                      style: TextStyle(
                                          fontSize: 14, color: Colors.grey),
                                    ),
                                    const Text(
                                      "#1,438",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                              const Padding(
                                padding:  EdgeInsets.only(
                                    top: 14.0, bottom: 14),
                                child: VerticalDivider(
                                  width: 12,
                                  thickness: 1,
                                ),
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.only(top: 20, right: 10),
                                child: Column(
                                  children: [
                                    Image.asset("assets/icons/pentagon.png"),
                                    const Text(
                                      "LOCAL RANK",
                                      style: TextStyle(
                                          fontSize: 14, color: Colors.grey),
                                    ),
                                    const Text(
                                      "#56",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18,
                                          color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        TabBar(
                          controller: _tabController,
                          tabs:const [
                            Tab(child: Text("Badge")),
                            Tab(child: Text("Stats")),
                            Tab(child: Text("Detail")),
                          ],
                          indicatorColor:const Color.fromARGB(255, 144, 110, 219),
                          labelColor:const Color.fromARGB(255, 144, 110, 219),
                          unselectedLabelColor: Colors.black,
                        ),
                        Expanded(
                          child: TabBarView(
                            controller: _tabController,
                            children:const [
                               BadgePage(),
                               StatPage(),
                               DetailPage(),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 130,
                top: 70,
                child: Image.asset("assets/icons/Avatarp.png"),
              ),
              Positioned(
                right: 130,
                top: 140,
                child: Image.asset("assets/icons/Flag.png"),
              ),
            ],
          ),
      ),
    );
  }
}
