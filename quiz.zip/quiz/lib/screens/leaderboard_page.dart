import 'package:flutter/material.dart';
import '../leaderboard/leaderboard_all_time_tab.dart';
import '../leaderboard/leaderboard_weekly_tab.dart';

class LeaderBoardPage extends StatefulWidget {
  const LeaderBoardPage({super.key});

  @override
  State<LeaderBoardPage> createState() => _LeaderBoardPageState();
}

class _LeaderBoardPageState extends State<LeaderBoardPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  BorderRadiusGeometry radius = const BorderRadius.only(
    topLeft: Radius.circular(24.0),
    topRight: Radius.circular(24.0),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFF6A5AE0),
        appBar: AppBar(
          toolbarHeight: 70,
          centerTitle: true,
          backgroundColor: const Color(0xFF6A5AE0),
          title: const Text(
            "Leaderboard",
            style: TextStyle(color: Colors.white),
          ),
          leading: IconButton(
            onPressed: () {},
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
          ),
        ),
        body: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(
            height: 40,
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Colors.transparent),
              ),
            ),
            child: TabBar(
              dividerColor: Colors.transparent,
              controller: _tabController,
              indicator: BoxDecoration(
                  color: const Color.fromARGB(255, 195, 210, 223),
                  borderRadius: BorderRadius.circular(16)),
              tabs: const [
                Tab(
                  child: Center(
                    child: Text(
                      'Weekly',
                      style: TextStyle(
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                Tab(
                  child: Center(
                    child: Text(
                      'All Time',
                      style: TextStyle(
                        color: Colors.white, // Text color of unselected tab
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children:const [
                LeaderBoardWeekly(),
                LeaderboardAllTime(),
              ],
            ),
          ),
        ]));
  }
}
